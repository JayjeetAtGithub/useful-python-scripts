# Import entire module
import greet

greet.sayHello('Tim')

# Import a specific element
from greet import sayGoodbye

sayGoodbye('Tom')