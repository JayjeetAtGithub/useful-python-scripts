def sayHello(name):
    print('Hello', name, 'From the greet module')
    return

def sayGoodbye(name):
    print('Goodbye', name, 'From the greet module')
    return