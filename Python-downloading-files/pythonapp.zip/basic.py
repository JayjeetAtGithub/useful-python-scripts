# COMMENTS

# This is a single line comment

'''
    This is a 
    multi line comment
'''

"""
    This is a 
    multi line comment
"""

# Single Quotes
print('Hello World')

# Double Quotes
print("Hello World")

# TIP - Stay Consitent with your quotes

# Triple Quotes
print("""Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse volutpat, 
nunc dignissim pellentesque porta, augue leo mollis massa, id hendrerit nunc ante at ex. 
Pellentesque in eleifend nulla. Mauris fringilla ultrices lectus, eu ornare quam ultricies non. 
Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis 
rhoncus purus ex, eget finibus mauris euismod sit amet. Pellentesque aliquet in dolor""")

# Print substrings
print('Hello'[0:3])

# Print number
print(2)

# Print on same line
print(1,2,3,'Hello')

print('LINE1\nLINE2\nLINE3')

print(r'C:\\somewhere\n')