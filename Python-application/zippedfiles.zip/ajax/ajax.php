<?php

 // echo "Hi there";

if(isset($_GET['name']))
{
	echo "Your name is :".$_GET['name'];
}

?>